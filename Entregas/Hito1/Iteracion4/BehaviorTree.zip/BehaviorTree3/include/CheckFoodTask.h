#ifndef CHECKFOODTASK_H
#define CHECKFOODTASK_H

#include "Node.h"

#include "Npc.h"

class CheckFoodTask : public Node
{
    public:

        CheckFoodTask(Npc* n);

        virtual ~CheckFoodTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKFOODTASK_H
