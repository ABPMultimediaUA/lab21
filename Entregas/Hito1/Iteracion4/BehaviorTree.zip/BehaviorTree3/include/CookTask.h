#ifndef COOKTASK_H
#define COOKTASK_H

#include "Node.h"

#include "Npc.h"

class CookTask : public Node
{
    public:

        CookTask(Npc* n);

        virtual ~CookTask();

        virtual States run ();

    protected:

    private:

        Npc* npc;
};

#endif // COOKTASK_H
