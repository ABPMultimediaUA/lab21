#ifndef NPC_H
#define NPC_H

#include "Location.h"
#include <iostream>

using namespace std;

class Npc
{
    public:

        Npc();

        virtual ~Npc();

        bool getSleeping();

        void setSleeping (bool sleep);

        int getHunger ();

        void setHunger (int hungry);

        int getPosition ();

        void setPosition (int p);

        int getFood();

        void setFood(int f);

        int getMoney();

        void setMoney(int m);

        void setFreetime(bool free);

        bool getFreetime();

        void setClean(bool c);

        bool getClean();

        void setBedtime(bool bed);

        bool getBedtime();

        Location getLocation();

        void setLocation(Location l);

        float getTime();

        void setTime();


    protected:

    private:

        bool sleeping;

        int hunger;

        int position;

        int food;

        int money;

        bool freetime;

        bool clean;

        bool bedtime;

        Location location;

        float time;
};

#endif // NPC_H
