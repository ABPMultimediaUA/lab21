#ifndef NODESTATES_H
#define NODESTATES_H

enum States
{
    success,
    failure,
    running
};


#endif // NODESTATES_H
