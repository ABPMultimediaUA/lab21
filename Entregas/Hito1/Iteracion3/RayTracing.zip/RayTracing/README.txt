Abrir ejecutable
El objetivo es mostrar por pantalla la deteccion de colisiones mediante el trazado de rayos.
Movimiento de la camara: Raton
Movimiento del protagonista: RightKet, LeftKey, UpKey, DownKey
Se puede observar al apuntar a los diversos objetos del mapa como varia el foco que les apunta.
Al acercarse a estos objetos tambien se puede observar el cambio de tamanyo de la mira
De esta manera podremos detectar las colisiones con los objetos en el futuro en nuestro motor.