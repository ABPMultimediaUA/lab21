#include "GoToWorkTask.h"

GoToWorkTask::GoToWorkTask(Npc* n, Map* m)
{
    //ctor
    brunning = false;
    npc = n;
    mapa = m;
}

GoToWorkTask::~GoToWorkTask()
{
    //dtor
}

States GoToWorkTask::run()
{
    /*npc->setHunger(npc->getHunger()+1);

    int pos = npc->getPosition();

    int* mapp = mapa->getMap();

    int i;

    for (i = 0; i < 9; i++)
            cout << mapp[i] << " " ;
        cout << endl;


    if(pos > 0)
    {

        npc->setPosition(pos-1);
        cout << "Going to work." << endl;

        mapa->setMap(npc->getPosition());

        brunning = true;
        return running;
    }

    cout << "At work." << endl;

    brunning = false;
    return success;*/

    cout<<"At work."<<endl;
    npc->setLocation(work);
    return success;


}
