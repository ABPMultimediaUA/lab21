#include "UnlockDoorTask.h"

UnlockDoorTask::UnlockDoorTask()
{
    //ctor
}

UnlockDoorTask::~UnlockDoorTask()
{
    //dtor
}

bool UnlockDoorTask::run()
{

    if (status->stronglyLocked)
    {
        cout << "The person can't unlock the door." << endl;

         return false;

    }

    status->locked = false;

    cout << "The person unlocks the door." << endl;

    return true;
}
