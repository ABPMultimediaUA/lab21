#include "OpenDoorTask.h"

OpenDoorTask::OpenDoorTask()
{
    //ctor
}

OpenDoorTask::~OpenDoorTask()
{
    //dtor
}

bool OpenDoorTask::run()
{

    if (status->locked)
    {
        cout << "The person tries to open the door but it seems that it is locked." << endl;
        return false;
    }


    status->doorIsOpen = true;  // run() not const because of this too

    cout << "The person opens the door." << endl;

    return true;
}
