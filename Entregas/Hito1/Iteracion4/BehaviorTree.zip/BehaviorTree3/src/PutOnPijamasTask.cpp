#include "PutOnPijamasTask.h"

PutOnPijamasTask::PutOnPijamasTask()
{
    //ctor
    brunning = false;
}

PutOnPijamasTask::~PutOnPijamasTask()
{
    //dtor
}

States PutOnPijamasTask::run()
{
    cout << "Putting on the pijamas." << endl;
    return success;
}
