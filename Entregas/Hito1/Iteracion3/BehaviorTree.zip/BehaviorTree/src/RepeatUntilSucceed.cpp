#include "RepeatUntilSucceed.h"

RepeatUntilSucceed::RepeatUntilSucceed()
{
    //ctor
    status = false;
}

RepeatUntilSucceed::~RepeatUntilSucceed()
{
    //dtor
}

bool RepeatUntilSucceed::run()
{

    while (status != true)
    {
        status = getChild()->run();

    }

    return true;
}
