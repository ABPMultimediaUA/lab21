#include "WorkTask.h"

WorkTask::WorkTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

WorkTask::~WorkTask()
{
    //dtor
}

States WorkTask::run ()
{

    cout<<"Working hard."<<endl;

    npc->setHunger(npc->getHunger()+1);

    return success;
}
