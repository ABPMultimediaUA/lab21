#include "CheckFoodTask.h"

CheckFoodTask::CheckFoodTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckFoodTask::~CheckFoodTask()
{
    //dtor
}

States CheckFoodTask::run()
{
    if (npc->getFood() > 0)
    {
        cout << "I have enough food for lunch." << endl;
        return success;
    }

    cout << "There is nothing to eat." << endl;
    return failure;
}
