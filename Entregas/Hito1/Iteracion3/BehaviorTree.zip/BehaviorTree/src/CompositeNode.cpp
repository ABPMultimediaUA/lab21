#include "CompositeNode.h"

CompositeNode::CompositeNode()
{
    //ctor
}

CompositeNode::~CompositeNode()
{
    //dtor
}

const list<Node*>& CompositeNode::getChildren() const
{
    return children;
}

void CompositeNode::addChild (Node* child)
{
    children.push_back(child);
}
