#ifndef LOCATION_H_INCLUDED
#define LOCATION_H_INCLUDED

enum Location
{
    home,
    work
};


#endif // LOCATION_H_INCLUDED
