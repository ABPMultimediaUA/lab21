 /\/\/\/\/\/\/\/\/\/\/\/\
( DireWolf Games - Lab21 )
 \/\/\/\/\/\/\/\/\/\/\/\/

UPDATE: Now the sfml lib is static. No more dll missing errors.

This executable shows a box loaded from a obj file with our own graphic engine.
We use Assimp Lib for model loading.

We have updated the executable using SFML instead of GLUT for window management.
Now it uses same classes of the Main Game (fachade) to be ready to change the 
Graphic Engine.

Just execute run.bat
You can rotate the box with ASDW keys and move the box with the cursor.


------------
Rubén Moreno