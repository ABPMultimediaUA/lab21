#ifndef CHECKBREAKTIMETASK_H
#define CHECKBREAKTIMETASK_H

#include "Node.h"

#include "Npc.h"

class CheckBreakTimeTask : public Node
{
    public:

        CheckBreakTimeTask(Npc* n);

        virtual ~CheckBreakTimeTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKBREAKTIMETASK_H
