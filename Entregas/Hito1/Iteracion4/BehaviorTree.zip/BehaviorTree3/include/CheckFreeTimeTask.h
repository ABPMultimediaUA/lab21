#ifndef CHECKFREETIMETASK_H
#define CHECKFREETIMETASK_H

#include "Node.h"

#include "Npc.h"

class CheckFreeTimeTask : public Node
{
    public:

        CheckFreeTimeTask(Npc* n);

        virtual ~CheckFreeTimeTask();

        virtual States run();



    protected:

    private:

        Npc* npc;

};

#endif // CHECKFREETIMETASK_H
