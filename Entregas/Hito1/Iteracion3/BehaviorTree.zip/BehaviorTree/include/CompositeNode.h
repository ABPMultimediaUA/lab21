#ifndef COMPOSITENODE_H
#define COMPOSITENODE_H

#include "Node.h"
#include <list>

using namespace std;

class CompositeNode : public Node
{
    public:

        CompositeNode();

        virtual ~CompositeNode();

        const list<Node*>& getChildren() const;

        void addChild (Node* child);


    protected:

    private:

        list<Node*> children;
};

#endif // COMPOSITENODE_H
