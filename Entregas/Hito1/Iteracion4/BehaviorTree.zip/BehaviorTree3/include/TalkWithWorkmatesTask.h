#ifndef TALKWITHWORKMATESTASK_H
#define TALKWITHWORKMATESTASK_H

#include "Node.h"

class TalkWithWorkmatesTask : public Node
{
    public:

        TalkWithWorkmatesTask();

        virtual ~TalkWithWorkmatesTask();

        virtual States run();

    protected:

    private:
};

#endif // TALKWITHWORKMATESTASK_H
