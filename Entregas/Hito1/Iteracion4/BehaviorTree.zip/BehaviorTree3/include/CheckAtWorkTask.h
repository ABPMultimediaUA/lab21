#ifndef CHECKATWORKTASK_H
#define CHECKATWORKTASK_H

#include "Node.h"

#include "Npc.h"

class CheckAtWorkTask : public Node
{
    public:

        CheckAtWorkTask(Npc* n);

        virtual ~CheckAtWorkTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKATWORKTASK_H
