#ifndef NODE_H
#define NODE_H

#include <Global.h>

class Node
{
    public:

        Node();

        virtual ~Node();

        virtual bool run() = 0;


    protected:

    private:
};

#endif // NODE_H
