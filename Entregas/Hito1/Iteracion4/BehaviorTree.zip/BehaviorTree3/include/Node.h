#ifndef NODE_H
#define NODE_H

#include <iostream>

#include "NodeStates.h"

using namespace std;

class Node
{
   public:
        Node();
        virtual ~Node();
        virtual States run();
        bool getRunning();

    protected:
        bool brunning;

};

#endif // NODE_H
