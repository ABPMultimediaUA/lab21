#ifndef HAVELUNCHTASK_H
#define HAVELUNCHTASK_H

#include "Node.h"

#include "Npc.h"

class HaveLunchTask : public Node
{
    public:

        HaveLunchTask(Npc* n);

        virtual ~HaveLunchTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // HAVELUNCHTASK_H
