#include "GoToTheKitchenTask.h"

GoToTheKitchenTask::GoToTheKitchenTask(Npc* n, Map* m)
{
    //ctor
    brunning = false;
    npc = n;
    mapa = m;
}

GoToTheKitchenTask::~GoToTheKitchenTask()
{
    //dtor
}

States GoToTheKitchenTask::run()
{

    int pos = npc->getPosition();

    int* mapp = mapa->getMap();

    int i;

    for (i = 0; i < 9; i++)
            cout << mapp[i] << " " ;
        cout << endl;


    if(pos < 8)
    {

        npc->setPosition(pos+1);
        cout << "Walking to the kitchen." << endl;

        mapa->setMap(npc->getPosition());


        brunning = true;
        return running;
    }

    cout << "In the kitchen." << endl;

    brunning = false;
    return success;
}
