#ifndef HAVESHOWERTASK_H
#define HAVESHOWERTASK_H

#include "Node.h"

#include "Npc.h"

class HaveShowerTask : public Node
{
    public:

        HaveShowerTask(Npc* n);

        virtual ~HaveShowerTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // HAVESHOWERTASK_H
