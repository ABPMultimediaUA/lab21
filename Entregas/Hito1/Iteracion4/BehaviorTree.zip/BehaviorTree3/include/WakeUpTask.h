#ifndef WAKEUPTASK_H
#define WAKEUPTASK_H

#include "Node.h"

#include "Npc.h"

class WakeUpTask : public Node
{
    public:

        WakeUpTask(Npc* n);

        virtual ~WakeUpTask();

        virtual States run();



    protected:

    private:

        Npc* npc;
};

#endif // WAKEUPTASK_H
