#include <windows.h>
#include <conio.h>

#include "Node.h"
#include "CompositeNode.h"
#include "DecoratorNode.h"
#include "Selector.h"
#include "Sequence.h"
#include "Succeeder.h"
#include "RepeatUntilSucceed.h"
#include "CheckIfDoorIsOpenTask.h"
#include "ApproachDoorTask.h"
#include "OpenDoorTask.h"
#include "UnlockDoorTask.h"
#include "SmashDoorTask.h"
#include "WalkThroughDoorTask.h"
#include "CloseDoorTask.h"
#include "Global.h"

/* Node states
#define SUCCESS = 1;
#define FAILURE = 2;
#define RUNNING = 3;
*/

using namespace std;

int main()
{

    /**** Special nodes ****/

	Sequence *root = new Sequence;  // Note that root can be either a Sequence or a Selector, since it has only one child.

	Sequence *sequence1 = new Sequence;
    Sequence *sequence2 = new Sequence;
    Sequence *sequence3 = new Sequence;

	Selector* selector1 = new Selector;  // In general there will be several nodes that are Sequence or Selector, so they should be suffixed by an integer to distinguish between them.
    Selector* selector2 = new Selector;

    Succeeder* succeeder1 = new Succeeder;

    RepeatUntilSucceed* repeatuntilsucceed1 = new RepeatUntilSucceed;



    /**** Asking about door status ****/

    char r;
    bool b1, b2, b3, b4;
    int dist;


    do {
        cout <<  "First of all: how far is the door? (Answer with a number 0-10)" << endl;

        cin >> dist;

    } while (dist < 0 || dist > 10);

    cout << " Now tell us if the door is: " << endl;

    do {
        cout << "- open? (y/n)" << endl;

        cin >> r;

        if (r == 'y')
            b1 = true;

        else
            b1 = false;

    } while (r!= 'y' && r!= 'n');


    if (b1 == false)
    {
        do {
            cout << "- locked? (y/n)" << endl;

            cin >> r;

            if (r == 'y')
                b2 = true;

            else
                b2 = false;

        } while (r!= 'y' && r!= 'n');


        if (b2 == true)
        {
            do {
                cout << "- strongly locked? (y/n)" << endl;

                cin >> r;

                if (r == 'y')
                    b3 = true;

                else
                    b3 = false;

            } while (r!= 'y' && r!= 'n');

            if (b3 == true)
            {
                do {
                    cout << "- impossible to open? (y/n)" << endl;

                    cin >> r;

                    if (r == 'y')
                        b4 = true;

                    else
                        b4 = false;

                } while (r!= 'y' && r!= 'n');
            }

        }

    }


    /**** Door status ****/

    // doorIsOpen, locked, stronglyLocked, impossibleToOpen, distanceToDoor
	struct DoorStatus doorStatus = {b1, b2, b3, b4, dist};



    /**** Tasks ****/

	CheckIfDoorIsOpenTask* checkOpen = new CheckIfDoorIsOpenTask (&doorStatus);
	ApproachDoorTask* approach = new ApproachDoorTask (&doorStatus);
	OpenDoorTask* open = new OpenDoorTask (&doorStatus);
	UnlockDoorTask* unlock = new UnlockDoorTask (&doorStatus);
	WalkThroughDoorTask* through = new WalkThroughDoorTask ();
	SmashDoorTask* smash = new SmashDoorTask (&doorStatus);
	CloseDoorTask* close = new CloseDoorTask (&doorStatus);



    /**** Creating the tree ****/

	root->addChild (selector1);

	selector1->addChild (sequence3);
	selector1->addChild (sequence1);

    sequence3->addChild (checkOpen);
    sequence3->addChild (repeatuntilsucceed1);
    sequence3->addChild (through);
    sequence3->addChild (close);

	sequence1->addChild (repeatuntilsucceed1);
	sequence1->addChild(selector2);
	sequence1->addChild(through);
	sequence1->addChild(succeeder1);

	repeatuntilsucceed1->setChild(approach);

	succeeder1->setChild(close);

	selector2->addChild(open);
	selector2->addChild(sequence2);
	selector2->addChild(smash);

	sequence2->addChild(unlock);
	sequence2->addChild(open);



    /**** Running the tree ****/

	(!root->run());



    /**** Ending ****/

    cout << "--------------------" << endl;

	cout << endl << "Operation complete.  Behaviour tree exited." << endl;
	cin.get();

	cout << endl;
    cout << "Press any key to continue." << endl;

    getch();

	return 0;
}
