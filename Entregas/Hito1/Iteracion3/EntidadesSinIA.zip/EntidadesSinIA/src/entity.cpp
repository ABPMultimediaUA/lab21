#include "entity.h"

entity::entity()
{
    //ctor
}

entity::~entity()
{
    //dtor
}

void entity::render()
{

}

void entity::update()
{

}
