#ifndef SUCCEEDER_H
#define SUCCEEDER_H

#include "DecoratorNode.h"

class Succeeder : public DecoratorNode
{
    public:

        Succeeder();

        virtual ~Succeeder();

        virtual States run();


};

#endif // SUCCEEDER_H
