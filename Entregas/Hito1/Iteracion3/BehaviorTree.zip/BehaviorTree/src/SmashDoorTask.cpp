#include "SmashDoorTask.h"

SmashDoorTask::SmashDoorTask()
{
    //ctor
}

SmashDoorTask::~SmashDoorTask()
{
    //dtor
}

bool SmashDoorTask::run()
{

    cout << "The person tries to smash the door." << endl;


    if (status->impossibleToOpen)
    {

        cout << "The door is impossible to open." << endl;

        return false;

    }


    status->stronglyLocked = false;

    cout << "The person smashes the door." << endl;

    return true;
}
