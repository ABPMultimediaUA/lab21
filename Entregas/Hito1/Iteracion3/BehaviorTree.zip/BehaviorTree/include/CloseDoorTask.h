#ifndef CLOSEDOORTASK_H
#define CLOSEDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class CloseDoorTask : public Node
{
    public:

        CloseDoorTask();

        virtual ~CloseDoorTask();

        CloseDoorTask (DoorStatus* status) : status(status) {};

        virtual bool run();


    protected:

    private:

        DoorStatus* status;
};

#endif // CLOSEDOORTASK_H
