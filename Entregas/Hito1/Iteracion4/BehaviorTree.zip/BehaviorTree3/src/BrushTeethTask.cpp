#include "BrushTeethTask.h"

BrushTeethTask::BrushTeethTask()
{
    //ctor
    brunning = false;
}

BrushTeethTask::~BrushTeethTask()
{
    //dtor
}

States BrushTeethTask::run()
{
    cout << "Brushing teeth" << endl;
    return success;
}
