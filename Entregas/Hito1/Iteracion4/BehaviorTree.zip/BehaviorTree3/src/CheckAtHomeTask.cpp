#include "CheckAtHomeTask.h"

CheckAtHomeTask::CheckAtHomeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckAtHomeTask::~CheckAtHomeTask()
{
    //dtor
}

States CheckAtHomeTask::run()
{
    if(npc->getLocation() == home)
        return success;
    return failure;
}
