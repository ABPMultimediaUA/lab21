#include "TalkWithWorkmatesTask.h"

TalkWithWorkmatesTask::TalkWithWorkmatesTask()
{
    //ctor
    brunning = false;
}

TalkWithWorkmatesTask::~TalkWithWorkmatesTask()
{
    //dtor
}

States TalkWithWorkmatesTask::run()
{
    cout<<"Bla bla bla, i have friends =3"<<endl;
    return success;
}
