#include "ApproachDoorTask.h"


ApproachDoorTask::ApproachDoorTask()
{
    //ctor
}

ApproachDoorTask::~ApproachDoorTask()
{
    //dtor
}

bool ApproachDoorTask::run()
{

    if(status->distanceToDoor > 0)
    {
        status->distanceToDoor--;  // this run() is not a const function

        cout << "The person approaches the door." << endl;

        if (status->distanceToDoor > 1)
            cout << "The person is now " << status->distanceToDoor << " meters from the door." << endl;
        else if (status->distanceToDoor == 1)
            cout << "The person is now only one meter away from the door." << endl;
        else
            cout << "The person is at the door." << endl;

        return false;
    }

    return true;
}
