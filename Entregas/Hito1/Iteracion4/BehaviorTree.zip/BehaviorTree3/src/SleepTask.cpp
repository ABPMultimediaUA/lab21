#include "SleepTask.h"

SleepTask::SleepTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

SleepTask::~SleepTask()
{
    //dtor
}

States SleepTask::run()
{
    cout << "Let's go sleep." << endl;

    npc->setSleeping(true);

    return success;
}
