#include "tag/ELight.h"

tag::ELight::ELight()
{
    //ctor
}

tag::ELight::~ELight()
{
    //dtor
}

void tag::ELight::beginDraw() {};
void tag::ELight::endDraw() {};
