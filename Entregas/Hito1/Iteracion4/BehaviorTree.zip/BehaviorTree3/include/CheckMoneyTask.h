#ifndef CHECKMONEYTASK_H
#define CHECKMONEYTASK_H

#include "Node.h"

#include "Npc.h"

class CheckMoneyTask : public Node
{
    public:

        CheckMoneyTask(Npc* n);

        virtual ~CheckMoneyTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKMONEYTASK_H
