#include "Succeeder.h"

Succeeder::Succeeder()
{
    //ctor
}

Succeeder::~Succeeder()
{
    //dtor
}

bool Succeeder::run()
{
    getChild()->run();

    return true;
}

