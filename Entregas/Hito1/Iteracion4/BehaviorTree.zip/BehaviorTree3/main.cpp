#include <iostream>
#include <conio.h>
#include <windows.h>

#include "Tree.h"

using namespace std;

int main()
{
    Npc* npc = new Npc();
    Map* mapa = new Map();
    Tree* tree = new Tree (npc, mapa);

    int i;

    for (i = 0; i < 240; i++)
    {
        cout << "Hago run " << i << " " << endl;
        tree->run();
        cout << "-------------" << endl;
        Sleep(500);
    }

    delete npc;
    delete mapa;
    delete tree;


    cout << endl << "Operation complete.  Behaviour tree exited." << endl;
	cin.get();

	cout << endl;
    cout << "Press any key to continue." << endl;

    getch();

    return 0;
}
