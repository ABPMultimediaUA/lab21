#include "Node.h"

Node::Node()
{
    //ctor
}

Node::~Node()
{
    //dtor
}

States Node::run()
{
    return success;
}

bool Node::getRunning()
{
    return brunning;
}
