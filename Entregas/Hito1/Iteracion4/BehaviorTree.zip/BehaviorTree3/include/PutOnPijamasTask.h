#ifndef PUTONPIJAMASTASK_H
#define PUTONPIJAMASTASK_H

#include "Node.h"

class PutOnPijamasTask : public Node
{
    public:

        PutOnPijamasTask();

        virtual ~PutOnPijamasTask();

        virtual States run();

    protected:

    private:
};

#endif // PUTONPIJAMASTASK_H
