#include "CheckEndWorkTimeTask.h"

CheckEndWorkTimeTask::CheckEndWorkTimeTask(Npc *n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckEndWorkTimeTask::~CheckEndWorkTimeTask()
{
    //dtor
}

States CheckEndWorkTimeTask::run()
{
    if(npc->getTime() >= 14.0)
    {
        cout << "Time to go home." << endl;
        return success;
    }

    return failure;
}
