#include "Sequence.h"

Sequence::Sequence()
{
    //ctor
}

Sequence::~Sequence()
{
    //dtor
}

bool Sequence::run()
{
    for (Node* child : getChildren())
    {
        if (!child->run())  // If one child fails, then enter operation run() fails.  Success only results if all children succeed.
            return false;
    }
    return true;  // All children suceeded, so the entire run() operation succeeds.
}
