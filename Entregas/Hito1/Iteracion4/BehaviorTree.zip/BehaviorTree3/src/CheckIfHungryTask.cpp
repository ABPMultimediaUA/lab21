#include "CheckIfHungryTask.h"

CheckIfHungryTask::CheckIfHungryTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckIfHungryTask::~CheckIfHungryTask()
{
    //dtor
}

States CheckIfHungryTask::run()
{
    if (npc->getHunger() > 5)
    {
        cout << "I'm starving." << endl;
        return success;
    }
    else
    {
        cout << "I'm not hungry at the moment." << endl;
        return failure;
    }

}
