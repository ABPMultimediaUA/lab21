#include "Map.h"

Map::Map()
{
    //ctor
    mapa[0] = 0;
    mapa[1] = 2;
    mapa[2] = 3;
    mapa[3] = 4;
    mapa[4] = 5;
    mapa[5] = 6;
    mapa[6] = 7;
    mapa[7] = 8;
    mapa[8] = 9;
}

Map::~Map()
{
    //dtor
}

void Map::setMap(int p)
{
    int i;
    for (i = 0; i < 9; i++)
        mapa[i] = i+1;
    mapa[p] = 0;
}

int* Map::getMap()
{
    return mapa;
}
