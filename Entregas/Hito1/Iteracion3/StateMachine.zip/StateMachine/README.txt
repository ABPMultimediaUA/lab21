Se ha de ejecutar StateMachine.exe.

En este ejecutable los diferentes enemigos van cambiando su estado, llevando a cabo diferentes acciones seg�n entren, ejecuten o salgan de un estado.

Los estados est�n gestionados mediante una m�quina de estados.

El c�digo fuente se encuentra en las carpetas "src" e "include".