#ifndef CHECKIFBEDTIMETASK_H
#define CHECKIFBEDTIMETASK_H

#include "Node.h"

#include "Npc.h"

class CheckIfBedTimeTask : public Node
{
    public:

        CheckIfBedTimeTask(Npc* n);

        virtual ~CheckIfBedTimeTask();

        virtual States run();


    protected:

    private:

        Npc* npc;
};

#endif // CHECKIFBEDTIMETASK_H
