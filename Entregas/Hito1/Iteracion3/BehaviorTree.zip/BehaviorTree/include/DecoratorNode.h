#ifndef DECORATORNODE_H
#define DECORATORNODE_H

#include "Node.h"

using namespace std;

class DecoratorNode : public Node
{
    public:

        DecoratorNode();

        virtual ~DecoratorNode();

        Node*& getChild();

        void setChild (Node* nchild);

    protected:

    private:

        Node* child;
};

#endif // DECORATORNODE_H
