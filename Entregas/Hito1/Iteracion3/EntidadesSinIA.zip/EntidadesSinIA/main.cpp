#include <iostream>
#include <conio.h>
#include "entity.h"
#include "door.h"
#include "generator.h"
#include "projectile.h"

using namespace std;

int main()
{
    door *p, *alone;
    cout<<"Creo una puerta auxiliar y una puerta funcional independiente"<<endl;
    /*La puerta independiente ira en un conjunto de entidades independientes que no
    necesiten generador, ya que funcionaran desde un principio*/
    alone=new door(50, 50, 3, true);
    cout<<"Creo el generador 'g1'"<<endl;
    generator *g1=new generator(0, false);
    cout<<"Creo el generador 'g2'"<<endl;
    generator *g2=new generator(1, true);
    cout<<"Creo un conjunto de entidades de un sector"<<endl;
    entity **entities=new entity*;
    cout<<"Creo un segundo conjunto de entidades de otro sector"<<endl;
    entity **entities2=new entity*;
    cout<<"Relleno el primer sector con 2 puertas"<<endl;
    entities[0]=new door(0, 0, 0, false);
    entities[1]=new door(100, 100, 1, false);
    cout<<"Relleno el segundo sector con 1 puerta"<<endl;
    entities2[0]=new door(-100, -100, 0, false);
    cout<<"Asigno el primer sector al primer generador y le digo que hay 2 entidades en el sector"<<endl;
    g1->setSector(entities, 2);
    cout<<"Asigno el segundo sector al segundo generador y le digo que hay 1 entidad en el sector"<<endl;
    g2->setSector(entities2, 1);
    cout<<"Intento abrir la primera puerta del primer sector (apagado)"<<endl;
    p=(door*)entities[0];
    p->setIsOpening();
    cout<<"La puerta se esta abriendo?(1=SI/0=NO): "<<p->getIsOpening()<<endl;
    cout<<"Intento abrir la puerta independiente"<<endl;
    alone->setIsOpening();
    cout<<"La puerta se esta abriendo?(1=SI/0=NO): "<<alone->getIsOpening()<<endl;
    cout<<"Activo el primer generador, activando el primer sector"<<endl;
    g1->activateGenerator();
    cout<<"Intento abrir la primera puerta del primer sector antes apagado, ahora activo"<<endl;
    p=(door*)entities[0];
    p->setIsOpening();
    cout<<"La puerta se esta abriendo?(1=SI/0=NO): "<<p->getIsOpening()<<endl;
    cout<<"Intento abrir la segunda puerta del primer sector antes apagado, ahora activo"<<endl;
    p=(door*)entities[1];
    p->setIsOpening();
    cout<<"La puerta se esta abriendo?(1=SI/0=NO): "<<p->getIsOpening()<<endl;
    cout<<"Intento abrir la puerta del segundo sector (apagado)"<<endl;
    p=(door*)entities2[0];
    p->setIsOpening();
    cout<<"La puerta se esta abriendo?(1=SI/0=NO): "<<p->getIsOpening()<<endl;
    cout<<"Creo un proyectil"<<endl;
    projectile *pro;
    cout<<"Creo coordenadas de origen y destino"<<endl;
    int *origin, *destination;
    origin=new int;
    destination=new int;
    origin[0]=0;
    origin[1]=0;
    destination[0]=0;
    destination[1]=5;
    cout<<"Inicializo proyectil"<<endl;
    pro=new projectile(origin, destination);
    cout<<"Muevo proyectil hasta que choca (Falta corregir el movimiento)"<<endl;
    while(!pro->getCollides())
    {
        pro->update();
        cout<<"("<<pro->getPosition()[0]<<","<<pro->getPosition()[1]<<")"<<endl;
        if(pro->getCollides()){
            cout<<"Proyectil colisiona"<<endl;
        }
    }
    cout<<"Comienzo a borrar"<<endl;
    delete entities;
    cout<<"Borro entities"<<endl;
    delete entities2;
    cout<<"Borro entities2"<<endl;
    delete alone;
    cout<<"Borro alone"<<endl;
    delete g1;
    cout<<"Borro g1"<<endl;
    delete g2;
    cout<<"Borro g2"<<endl;
    delete origin;
    cout<<"Borro origin"<<endl;
    delete destination;
    cout<<"Borro destination"<<endl;
    char a;
    cout<<"Pulsa cualquier tecla para salir";
    getch();
    return 0;
}
