#ifndef GOHOMETASK_H
#define GOHOMETASK_H

#include "Node.h"

#include "Npc.h"

class GoHomeTask : public Node
{
    public:

        GoHomeTask(Npc* n);

        virtual ~GoHomeTask();

        virtual States run();


    protected:

    private:

        Npc* npc;

};

#endif // GOHOMETASK_H
