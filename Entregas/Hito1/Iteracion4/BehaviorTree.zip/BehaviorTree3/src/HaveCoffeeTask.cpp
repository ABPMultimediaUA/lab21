#include "HaveCoffeeTask.h"

HaveCoffeeTask::HaveCoffeeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

HaveCoffeeTask::~HaveCoffeeTask()
{
    //dtor
}

States HaveCoffeeTask::run()
{
    npc->setMoney(npc->getMoney()-2);
    npc->setHunger(npc->getHunger()-4);
    cout<<"So tasty!"<<endl;
    return success;
}
