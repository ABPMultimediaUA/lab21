#ifndef GOTOWORKTASK_H
#define GOTOWORKTASK_H

#include "Node.h"

#include "Npc.h"

#include "Map.h"

class GoToWorkTask : public Node
{
    public:

        GoToWorkTask(Npc* n, Map* m);

        virtual ~GoToWorkTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
        Map* mapa;
};

#endif // GOTOWORKTASK_H
