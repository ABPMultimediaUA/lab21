#ifndef PLAYVIDEOGAMESTASK_H
#define PLAYVIDEOGAMESTASK_H

#include "Node.h"

#include "Npc.h"

class PlayVideoGamesTask : public Node
{
    public:

        PlayVideoGamesTask(Npc* n);

        virtual ~PlayVideoGamesTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // PLAYVIDEOGAMESTASK_H
