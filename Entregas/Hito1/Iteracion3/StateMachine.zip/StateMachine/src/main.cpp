#include <windows.h>
#include <conio.h>
#include <iostream>

#include "Bat.h"
#include "Mother.h"
#include "Guardian.h"
#include "Legless.h"
#include "Dog.h"
#include "Humanoid.h"

using namespace std;

int main()
{

    Bat         *bat        = new Bat();
    Mother      *mother     = new Mother();
    Guardian    *guardian   = new Guardian();
    Legless     *legless    = new Legless();
    Dog         *dog        = new Dog();
    Humanoid    *humanoid   = new Humanoid();


    int i;

    for (i=0; i<20; i++)
    {
        bat->Update();
        mother->Update();
        guardian->Update();
        legless->Update();
        dog->Update();
        humanoid->Update();

        Sleep(800);
    }

    cout << endl;
    cout << "Press any key to continue." << endl;

    getch();

    return 0;
}
