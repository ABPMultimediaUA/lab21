#ifndef TRIGGER_H
#define TRIGGER_H
#include "triggerRegion.h"

/******************************************************************************
Los trigger son los encargados de que se ejecute un evento al ser activados.
Tambien son generados al ocurrir algun evento.
*******************************************************************************/

class trigger
{
    public:
        trigger(int a, int b, int c, int d);
        virtual ~trigger();
        void isTriggered();
        void update();

    protected:

    private:
        triggerRegion *region;
        bool triggered;
};

#endif // TRIGGER_H
