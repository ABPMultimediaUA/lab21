#ifndef REPEATUNTILSUCCEED_H
#define REPEATUNTILSUCCEED_H

#include "DecoratorNode.h"

class RepeatUntilSucceed : public DecoratorNode
{
    public:

        RepeatUntilSucceed();

        virtual ~RepeatUntilSucceed();

        virtual bool run();

        bool status;

};

#endif // REPEATUNTILSUCCEED_H
