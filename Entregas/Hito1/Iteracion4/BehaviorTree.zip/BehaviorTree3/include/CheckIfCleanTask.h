#ifndef CHECKIFCLEANTASK_H
#define CHECKIFCLEANTASK_H

#include "Node.h"

#include "Npc.h"

class CheckIfCleanTask : public Node
{
    public:

        CheckIfCleanTask(Npc* n);

        virtual ~CheckIfCleanTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKIFCLEANTASK_H
