#ifndef SCENE_H
#define SCENE_H


class Program;

class Scene
{
    public:
        Scene();
        virtual ~Scene();

    protected:

    private:
};

#endif // SCENE_H
