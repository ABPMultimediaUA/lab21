#include "CheckIfBedTimeTask.h"

CheckIfBedTimeTask::CheckIfBedTimeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckIfBedTimeTask::~CheckIfBedTimeTask()
{
    //dtor
}

States CheckIfBedTimeTask::run()
{
    if (npc->getTime() >= 23.0)
    {
        cout << "It's late, I have to go to bed." << endl;
        return success;
    }

    cout << "It's not sleep time yet." << endl;
    return failure;
}
