#ifndef ENEMY_H
#define ENEMY_H




class Enemy
{
    public:
        Enemy();
        virtual ~Enemy();

    protected:

    private:
};

#endif // ENEMY_H
