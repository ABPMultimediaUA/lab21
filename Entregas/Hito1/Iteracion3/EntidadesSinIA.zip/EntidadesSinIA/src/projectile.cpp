#include "projectile.h"
#include <iostream>

using namespace std;


projectile::projectile(int *o, int *d)
{
    origin=o;
    destination=d;
    speed=5;
    position=new double;
    position[0]=0;
    position[1]=0;
    angle=atan2(destination[0] - origin[0], destination[1] - origin[1]); // Corregir
    collides=false;
}

projectile::~projectile()
{
    delete origin;
    delete destination;
    delete position;
}

void projectile::moveProjectile()
{
    if(position[0]<-50 || position[0]>50 || position[1]<-50 || position[1]>50)
        collides=true;
    if(!collides)
    {
        // Corregir
        position[0]=position[0]+(speed*cos(angle));
        position[1]=position[1]+(-speed*sin(angle));
    }
}

bool projectile::getCollides(){return collides;}

double* projectile::getPosition(){return position;}

void projectile::render()
{
    //Dibujar nodo
}

void projectile::update()
{
    if(!collides)
        moveProjectile();
    else
        delete this;
}
