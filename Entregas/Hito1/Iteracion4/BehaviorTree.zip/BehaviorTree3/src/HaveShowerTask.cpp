#include "HaveShowerTask.h"

HaveShowerTask::HaveShowerTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

HaveShowerTask::~HaveShowerTask()
{
    //dtor
}

States HaveShowerTask::run()
{
    cout << "Having shower." << endl;

    npc->setClean(true);

    return success;
}
