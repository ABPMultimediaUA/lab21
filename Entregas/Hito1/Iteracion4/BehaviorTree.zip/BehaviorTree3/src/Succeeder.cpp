#include "Succeeder.h"

Succeeder::Succeeder()
{
    //ctor
    brunning = false;
}

Succeeder::~Succeeder()
{
    //dtor
}

States Succeeder::run()
{
    getChild()->run();

    return success;
}

