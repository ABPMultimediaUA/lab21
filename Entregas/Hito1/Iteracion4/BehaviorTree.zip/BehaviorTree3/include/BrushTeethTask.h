#ifndef BRUSHTEETHTASK_H
#define BRUSHTEETHTASK_H

#include "Node.h"

class BrushTeethTask : public Node
{
    public:

        BrushTeethTask();

        virtual ~BrushTeethTask();

        virtual States run();

    protected:

    private:
};

#endif // BRUSHTEETHTASK_H
