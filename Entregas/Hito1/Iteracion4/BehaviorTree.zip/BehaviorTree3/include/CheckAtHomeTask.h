#ifndef CHECKATHOMETASK_H
#define CHECKATHOMETASK_H

#include "Node.h"

#include "Npc.h"

class CheckAtHomeTask : public Node
{
    public:

        CheckAtHomeTask(Npc* n);

        virtual ~CheckAtHomeTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKATHOMETASK_H
