#include "tag/ECamera.h"

tag::ECamera::ECamera()
{
    //ctor
}

tag::ECamera::~ECamera()
{
    //dtor
}

void tag::ECamera::beginDraw() {};
void tag::ECamera::endDraw() {};
