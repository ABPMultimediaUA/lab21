#ifndef MAP_H
#define MAP_H
#include <iostream>
#include <list>


using namespace std;

class Map
{
    public:

        Map();

        virtual ~Map();

        void setMap(int p);

        int* getMap();



    protected:

    private:

        int mapa[9];
};

#endif // MAP_H
