#include "CheckBreakTimeTask.h"

CheckBreakTimeTask::CheckBreakTimeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckBreakTimeTask::~CheckBreakTimeTask()
{
    //dtor
}

States CheckBreakTimeTask::run()
{
    if(npc->getTime() >= 10.0 && npc->getTime() < 11.0)
    {
        cout<<"Finally, break time."<<endl;
        return success;
    }

    return failure;
}
