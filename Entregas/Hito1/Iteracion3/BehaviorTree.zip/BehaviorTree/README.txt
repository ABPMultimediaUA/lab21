En este ejecutable aparecen una serie de preguntas para determinar el estado de la puerta que un personaje desea abrir.
Al preguntar por la distancia ha de responderse con un n�mero entero entre 0 y 10.
El resto de preguntas, con "y" para "s�" y "n" para "no".

Las acciones que el personaje realiza est�n determinadas por un �rbol de comportamiento.