#include "CheckFreeTimeTask.h"

CheckFreeTimeTask::CheckFreeTimeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckFreeTimeTask::~CheckFreeTimeTask()
{
    //dtor
}

States CheckFreeTimeTask::run()
{
    if(npc->getTime() < 9.0 || (npc->getTime() >= 14.0 && npc->getTime() < 23.0))
    {
        cout << "I have free time today." << endl;
        //npc->setFreeTime(false);
        return success;
    }

    cout << "I don't have time for anything right now." << endl;
    //npc->setFreeTime(true);
    return failure;

}
