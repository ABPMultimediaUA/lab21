#ifndef UNLOCKDOORTASK_H
#define UNLOCKDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class UnlockDoorTask : public Node
{
    public:

        UnlockDoorTask();

        virtual ~UnlockDoorTask();

        UnlockDoorTask (DoorStatus* status) : status(status) {};

        virtual bool run();

    protected:

    private:

        DoorStatus* status;
};

#endif // UNLOCKDOORTASK_H
