#ifndef CHECKENDWORKTIMETASK_H
#define CHECKENDWORKTIMETASK_H

#include "Node.h"

#include "Npc.h"

class CheckEndWorkTimeTask : public Node
{
    public:

        CheckEndWorkTimeTask(Npc* n);

        virtual ~CheckEndWorkTimeTask();

        virtual States run();

    protected:

    private:

        Npc* npc;

};

#endif // CHECKENDWORKTIMETASK_H
