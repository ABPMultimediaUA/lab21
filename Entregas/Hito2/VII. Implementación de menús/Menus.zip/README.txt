VII.Menú Principal provisional de LAB 21

Una vez iniciado el juego aparecerá el Menú principal con las siguientes opciones:

"Play Alone"
---------------------- 
Click en "Play Alone" para partida individual.

"Play Online"
---------------------
Para jugar en modo multijugador.
Primero es necesario compilar Lab21Server.cpb
Ejecutar "servidor.bat" una vez. Después, "game.bat" dos veces, una para cada instancia del juego.
En cada pantalla aparecerá el menú. 
- En una de ellas (llamémosla "pantalla 1") seleccionar "Play Online", cuando solicite servidor, "0", y cuando solicite partida, "0" para crear una.
- Tras esto, en la "pantalla 2" seleccionamos "Play Online", "0" para el servidor y "1" para la partida, ya creada.
- Finalmente, para empezar el juego, en la "pantalla 1" pulsamos la tecla Enter.

Esta parte se mejorará para que se pueda seleccionar los servidores dentro del propio menú y no en consola.

"Logros"
---------------------
Falta implementar un sistema de logros en el juego en un futuro.

"Opciones"
---------------------
Se podrá modificar el sonido y la resolución entre otras cosas en un futuro.

"Exit"
---------------------
Click en "Exit" para salir del juego.

Se adjunta un Boceto de los Menús del juego. 