#ifndef SLEEPTASK_H
#define SLEEPTASK_H

#include "Node.h"

#include "Npc.h"

class SleepTask : public Node
{
    public:

        SleepTask(Npc* n);

        virtual ~SleepTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // SLEEPTASK_H
