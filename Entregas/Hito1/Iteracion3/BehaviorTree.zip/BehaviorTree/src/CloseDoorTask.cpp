#include "CloseDoorTask.h"

CloseDoorTask::CloseDoorTask()
{
    //ctor
}

CloseDoorTask::~CloseDoorTask()
{
    //dtor
}

bool CloseDoorTask::run()
{
    if (!status->doorIsOpen)
        return false;

    status->doorIsOpen = false;  // run() not const because of this too

    cout << "The person closes the door." << endl;

    return true;

}
