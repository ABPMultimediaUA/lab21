#include "Npc.h"

Npc::Npc()
{
    //ctor
    sleeping = true;
    hunger = 8;
    position = 0;
    food = 1;
    money = 2;
    freetime = false;
    clean = false;
    bedtime = true;
    location = home;
    time = 6.0;
}

Npc::~Npc()
{
    //dtor
}

bool Npc::getSleeping()
{
    return sleeping;
}

void Npc::setSleeping(bool sleep)
{
    sleeping = sleep;
}

int Npc::getHunger()
{
    return hunger;
}

void Npc::setHunger(int hungry)
{
    hunger = hungry;
}

int Npc::getPosition()
{
    return position;
}

void Npc::setPosition (int p)
{
    position = p;
}

int Npc::getFood()
{
    return food;
}

void Npc::setFood(int f)
{
    food = f;
}

int Npc::getMoney()
{
    return money;
}

void Npc::setMoney(int m)
{
    money = m;
}

bool Npc::getFreetime()
{
    return freetime;
}

void Npc::setFreetime(bool free)
{
    freetime = free;
}

bool Npc::getClean()
{
    return clean;
}

void Npc::setClean(bool c)
{
    clean = c;
}

bool Npc::getBedtime()
{
    return bedtime;
}

void Npc::setBedtime(bool bed)
{
    bedtime = bed;
}

Location Npc::getLocation()
{
    return location;
}

void Npc::setLocation(Location l)
{
    location = l;
}

float Npc::getTime()
{
    return time;
}

void Npc::setTime()
{
    time = time + 0.1;
    if(time >= 24.0)
        time = 0.0;
    cout<<"Time: "<<time<<endl;
}
