#include "CheckMoneyTask.h"

CheckMoneyTask::CheckMoneyTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckMoneyTask::~CheckMoneyTask()
{
    //dtor
}

States CheckMoneyTask::run()
{
    if(npc->getMoney() > 1)
    {
        cout<<"I can afford a coffee."<<endl;
        return success;
    }

    cout<<"I don't have enough cash on me."<<endl;
    return failure;
}
