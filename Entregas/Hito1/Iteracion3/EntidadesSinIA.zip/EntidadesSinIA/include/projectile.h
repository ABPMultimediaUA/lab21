#ifndef PROJECTILE_H
#define PROJECTILE_H
#include <cmath>
#include "entity.h"

/******************************************************************************
Los proyectiles son los elementos que viajan de una posicion a otra del espacio
y haran una funcion diferente dependiendo del tipo de proyectil que sea.
*******************************************************************************/

class projectile: public entity
{
    public:
        projectile(int *o, int *d);
        virtual ~projectile();
        void moveProjectile();
        bool getCollides();
        double* getPosition();
        virtual void render();
        virtual void update();

    protected:

    private:
        // Futuramente vector2d
        int *origin;
        int *destination;

        // Futuramente nodo
        double *position;

        int speed;
        float angle;
        bool collides;
        // nodo proyectil
};

#endif // PROJECTILE_H
