#include "CheckIfCleanTask.h"

CheckIfCleanTask::CheckIfCleanTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckIfCleanTask::~CheckIfCleanTask()
{
    //dtor
}

States CheckIfCleanTask::run()
{
    if (npc->getClean())
    {
        cout << "I'm clean." << endl;
        return success;
    }

    cout << "I need a shower." << endl;
    return failure;
}
