#include "CookTask.h"

CookTask::CookTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CookTask::~CookTask()
{
    //dtor
}

States CookTask::run()
{
    if(npc->getFood() < 3)
    {
        cout << "Cooking." << endl;
        npc->setFood(npc->getFood() + 1);
        brunning = true;
        return running;
    }

    brunning = false;
    cout << "I have enough food." << endl;
    return success;
}
