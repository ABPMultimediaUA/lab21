#include "HaveLunchTask.h"

HaveLunchTask::HaveLunchTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

HaveLunchTask::~HaveLunchTask()
{
    //dtor
}

States HaveLunchTask::run()
{

    if (npc->getHunger() > 0)
    {
        cout << "Having lunch." << endl;

        npc->setHunger(npc->getHunger() - 4);

        brunning = true;

        return running;
    }

    npc->setFood(npc->getFood() - 1);

    cout << "I can't eat more." << endl;

    brunning = false;
    return success;


}
