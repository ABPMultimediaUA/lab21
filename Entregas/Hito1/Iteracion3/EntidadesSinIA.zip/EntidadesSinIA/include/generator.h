#ifndef GENERATOR_H
#define GENERATOR_H
#include "entity.h"
#include "door.h"

/******************************************************************************
Los generadores se encargan de suministrar energia a las luces y puertas de
una zona que se encuentre desactivada.
*******************************************************************************/

class generator: public entity
{
    public:
        generator(int n, bool b);
        virtual ~generator();
        void setSector(entity **s, int e);
        void activateGenerator(); // Activa generador
        virtual void render();
        virtual void update();
    protected:

    private:
        int num;
        bool active;
        int entities; // A cuantas entidades esta relacionado
        entity **sector; // Array de entidades
        // nodo generador
};

#endif // GENERATOR_H
