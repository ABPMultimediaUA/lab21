#ifndef SMASHDOORTASK_H
#define SMASHDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class SmashDoorTask : public Node
{
    public:

        SmashDoorTask();

        virtual ~SmashDoorTask();

        SmashDoorTask (DoorStatus* status) : status(status) {};

        virtual bool run();

    protected:

    private:

        DoorStatus* status;
};

#endif // SMASHDOORTASK_H
