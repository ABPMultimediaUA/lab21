#ifndef OPENDOORTASK_H
#define OPENDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class OpenDoorTask : public Node
{
    public:

        OpenDoorTask();

        virtual ~OpenDoorTask();

        OpenDoorTask (DoorStatus* status) : status(status) {};

        virtual bool run();

    protected:

    private:

        DoorStatus* status;

};

#endif // OPENDOORTASK_H
