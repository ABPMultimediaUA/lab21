#include "Selector.h"

Selector::Selector()
{
    //ctor
}

Selector::~Selector()
{
    //dtor
}

bool Selector::run()
{

    for (Node* child : getChildren())
    {
        if (child->run())  // If one child succeeds, the entire operation run() succeeds.  Failure only results if all children fail.
            return true;
    }

    return false;  // All children failed so the entire run() operation fails.

}
