Abrir ejecutable
El objetivo es mostrar por pantalla la percepcion del npc.
Cambiar camara: Botones Num 1,2,3.
Movimiento del protagonista: RightKet, LeftKey, UpKey, DownKey.
Sigilo: LShift
Si entras en el primer circulo sin pulsar el boton sigilo te oira e ira hacia ti.
Si entras en el segundo circulo te oira aunque vayas en sigilo.
Dentro del primer circulo puedes ir en sigilo.
Se muestra tambien un campo visual, en caso de entrar en el, te vera e ira a por ti.
Para ocultar los campos de percepcion pulsa la tecla v.