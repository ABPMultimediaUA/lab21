#ifndef TRIGGERREGION_H
#define TRIGGERREGION_H

/******************************************************************************
Region del espacio en la que se encuentra un trigger. Al contactar con esta
el trigger hara su funcion.
*******************************************************************************/

class triggerRegion
{
    public:
        triggerRegion(int n, int m, int i, int u);
        virtual ~triggerRegion();

    protected:

    private:
        int a, b, c, d; // Rectangulo
};

#endif // TRIGGERREGION_H
