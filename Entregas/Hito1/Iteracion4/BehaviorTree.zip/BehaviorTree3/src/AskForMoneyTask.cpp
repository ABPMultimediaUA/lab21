#include "AskForMoneyTask.h"

AskForMoneyTask::AskForMoneyTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

AskForMoneyTask::~AskForMoneyTask()
{
    //dtor
}

States AskForMoneyTask::run()
{
    npc->setMoney(npc->getMoney()+3);
    cout<<"Lend me some money bro."<<endl;
    return success;
}
