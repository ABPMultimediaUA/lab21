#ifndef APPROACHDOORTASK_H
#define APPROACHDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class ApproachDoorTask : public Node
{
    public:

        ApproachDoorTask();

        virtual ~ApproachDoorTask();

        ApproachDoorTask (DoorStatus* status) : status(status) {};

        virtual bool run();

    protected:

    private:

        DoorStatus* status;

};

#endif // APPROACHDOORTASK_H
