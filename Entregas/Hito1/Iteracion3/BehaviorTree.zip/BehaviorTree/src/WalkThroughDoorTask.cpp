#include "WalkThroughDoorTask.h"

WalkThroughDoorTask::WalkThroughDoorTask()
{
    //ctor
}

WalkThroughDoorTask::~WalkThroughDoorTask()
{
    //dtor
}

bool WalkThroughDoorTask::run()
{

    cout << "The person is walking through the door." << endl;

    return true;
}
