#ifndef CHECKIFDOORISOPENTASK_H
#define CHECKIFDOORISOPENTASK_H

#include <iostream>

#include "Node.h"

using namespace std;


class CheckIfDoorIsOpenTask : public Node
{
    public:

        CheckIfDoorIsOpenTask();

        virtual ~CheckIfDoorIsOpenTask();

        CheckIfDoorIsOpenTask (DoorStatus* status) : status(status) {};  // ?

        virtual bool run();

    protected:

    private:

        DoorStatus* status;
};

#endif // CHECKIFDOORISOPENTASK_H
