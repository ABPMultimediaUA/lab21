#include "DecoratorNode.h"

DecoratorNode::DecoratorNode()
{
    //ctor
}

DecoratorNode::~DecoratorNode()
{
    //dtor
}

Node*& DecoratorNode::getChild()
{
    return child;
}

void DecoratorNode::setChild (Node* nchild)
{
    child = nchild;
}
