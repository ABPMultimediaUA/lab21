#ifndef COMPOSITENODE_H
#define COMPOSITENODE_H

#include "Node.h"

#define MAX_NODES 10

struct CompositeNode : public Node
{
    public:
        CompositeNode();
        virtual ~CompositeNode();
        void addChild (Node* child);
        int getNumChildren();


    protected:
        Node* children[MAX_NODES];
        int numChildren;
};

#endif // COMPOSITENODE_H
