 /\/\/\/\/\/\/\/\/\/\/\/\
( DireWolf Games - Lab21 )
 \/\/\/\/\/\/\/\/\/\/\/\/

This executable shows the Net Engine working.

First of all, we have to run server.bat to start the server. Just let it remain opened.

Now we can run as many instances of game.bat and choose the running instance of the server.
We can play games up to 4 players.

The first game instance acts as the game server. Press enter in this instance to start the game.

We can see other instance players moving, taking objects, opening doors... 

The enemy IA is calculated in each game instance. The game server periodically sends a message to synchronize all.

------------
Rubén Moreno