#ifndef HAVECOFFEETASK_H
#define HAVECOFFEETASK_H

#include "Node.h"

#include "Npc.h"

class HaveCoffeeTask : public Node
{
    public:

        HaveCoffeeTask(Npc* n);

        virtual ~HaveCoffeeTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // HAVECOFFEETASK_H
