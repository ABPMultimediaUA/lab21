#include "triggerRegion.h"

triggerRegion::triggerRegion(int n, int m, int i, int u)
{
    a=n;
    b=m;
    c=i;
    d=u;
}

triggerRegion::~triggerRegion()
{
    //dtor
}
