#ifndef ASKFORMONEYTASK_H
#define ASKFORMONEYTASK_H

#include "Node.h"

#include "Npc.h"

class AskForMoneyTask : public Node
{
    public:

        AskForMoneyTask(Npc* n);

        virtual ~AskForMoneyTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // ASKFORMONEYTASK_H
