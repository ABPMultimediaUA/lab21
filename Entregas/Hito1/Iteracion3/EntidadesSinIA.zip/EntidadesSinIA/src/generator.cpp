#include "generator.h"

generator::generator(int n, bool b)
{
    num=n;
    active=b;
    entities=0;
}

generator::~generator()
{
    delete sector;
}

void generator::setSector(entity **s, int e)
{
    sector=s;
    entities=e;
}

void generator::activateGenerator()
{
    door *d;
    if(!active)
    {
        active=true;
        for(int i=0; i<entities; i++)
        {
            d=(door*)sector[i];
            d->setActive();
        }
        //delete sec;
        delete d;
    }
}

void generator::render()
{
    if(!active)
    {
        //Generador desactivado
        //Dibujar nodo
    }
    else
    {
        //Generador activado
        //Dibujar nodo
    }
}

void generator::update()
{
    if(active){
        //Hacer ruidos y cosas
    }
}
