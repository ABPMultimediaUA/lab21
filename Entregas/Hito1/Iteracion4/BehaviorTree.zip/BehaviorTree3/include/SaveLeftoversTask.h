#ifndef SAVELEFTOVERSTASK_H
#define SAVELEFTOVERSTASK_H

#include "Node.h"

#include "Npc.h"

class SaveLeftoversTask : public Node
{
    public:

        SaveLeftoversTask(Npc* n);

        virtual ~SaveLeftoversTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // SAVELEFTOVERSTASK_H
