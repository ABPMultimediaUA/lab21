#include "PlayVideoGamesTask.h"

PlayVideoGamesTask::PlayVideoGamesTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

PlayVideoGamesTask::~PlayVideoGamesTask()
{
    //dtor
}

States PlayVideoGamesTask::run()
{
    npc->setHunger(npc->getHunger() + 1);
    cout << "Playing videogames." << endl;
    return success;
}
