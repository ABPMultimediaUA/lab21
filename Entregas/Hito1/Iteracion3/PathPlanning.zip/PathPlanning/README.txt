Abrir ejecutable
Las instrucciones de funcionamiento estan detalladas en el mismo ejecutable.
Se trata de un prototipo de path planning, carece de pathfinding.
El objetivo es ir hasta una posicion, y si recibe danyo, retrocedera hasta la posicion de inicio.