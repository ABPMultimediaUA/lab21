#ifndef TREE_H
#define TREE_H

#include "Npc.h"

#include "Map.h"

#include "Node.h"
#include "Selector.h"
#include "Sequence.h"
#include "Succeeder.h"

#include "WakeUpTask.h"
#include "CheckIfHungryTask.h"
#include "GoToTheKitchenTask.h"
#include "CheckFoodTask.h"
#include "HaveLunchTask.h"
#include "CookTask.h"
#include "SaveLeftoversTask.h"
#include "BrushTeethTask.h"
#include "CheckFreeTimeTask.h"
#include "PlayVideoGamesTask.h"
#include "CheckIfBedTimeTask.h"
#include "CheckIfCleanTask.h"
#include "HaveShowerTask.h"
#include "PutOnPijamasTask.h"
#include "SleepTask.h"
#include "GoToWorkTask.h"
#include "WorkTask.h"
#include "CheckMoneyTask.h"
#include "AskForMoneyTask.h"
#include "HaveCoffeeTask.h"
#include "CheckBreakTimeTask.h"
#include "TalkWithWorkmatesTask.h"
#include "WorkTask.h"
#include "CheckAtHomeTask.h"
#include "CheckAtWorkTask.h"
#include "GoHomeTask.h"
#include "CheckEndWorkTimeTask.h"


class Tree : public Node
{
    public:

        Tree(Npc* n, Map *m);

        virtual ~Tree();

        virtual States run();

        Node** getTree();

        int getNumNodes();

        void addNode (Node* node); // Para los nodos que no son hijos inmediatos

        Node* getRoot();


    protected:

    private:

        Selector* root;

        int numNodes;       // N�mero de nodos en el �rbol

        Node** tree;        // Todos los nodos del �rbol

        Npc* npc;
};

#endif // TREE_H
