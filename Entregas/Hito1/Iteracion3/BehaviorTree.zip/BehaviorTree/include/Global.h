#ifndef GLOBAL_H
#define GLOBAL_H

struct DoorStatus {
	bool doorIsOpen;
	bool locked;
	bool stronglyLocked;
	bool impossibleToOpen;
	int distanceToDoor;
};

extern DoorStatus doorStatus;

#endif // GLOBAL_H
