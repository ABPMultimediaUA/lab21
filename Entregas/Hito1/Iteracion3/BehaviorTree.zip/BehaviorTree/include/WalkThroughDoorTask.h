#ifndef WALKTHROUGHDOORTASK_H
#define WALKTHROUGHDOORTASK_H

#include <iostream>

#include "Node.h"

using namespace std;

class WalkThroughDoorTask : public Node
{
    public:

        WalkThroughDoorTask();

        virtual ~WalkThroughDoorTask();

        virtual bool run();

    protected:

    private:


};

#endif // WALKTHROUGHDOORTASK_H
