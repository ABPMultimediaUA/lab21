#include "WakeUpTask.h"

WakeUpTask::WakeUpTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

WakeUpTask::~WakeUpTask()
{
    //dtor
}

States WakeUpTask::run()
{
    if (npc->getSleeping() && (npc->getTime() < 7.0 || npc->getTime() > 23.0))
    {
        cout << "ZzzZzZz..." << endl;
        brunning = true;
        return running;
    }

    else
    {
        cout << "I'm awake." << endl;
        npc->setSleeping(false);
        return failure;
    }
 }
