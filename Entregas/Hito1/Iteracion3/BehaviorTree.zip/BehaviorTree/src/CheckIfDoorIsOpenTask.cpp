#include "CheckIfDoorIsOpenTask.h"

CheckIfDoorIsOpenTask::CheckIfDoorIsOpenTask()
{
    //ctor
}

CheckIfDoorIsOpenTask::~CheckIfDoorIsOpenTask()
{
    //dtor
}

bool CheckIfDoorIsOpenTask::run()
{
    if (status->doorIsOpen == true)
        cout << "The person sees that the door is open." << endl;  // will return true
    else
        cout << "The person sees that the door is closed." << endl;  // will return false

    return status->doorIsOpen;
}
