#ifndef CHECKIFHUNGRYTASK_H
#define CHECKIFHUNGRYTASK_H

#include "Node.h"

#include "Npc.h"

class CheckIfHungryTask : public Node
{

    public:

        CheckIfHungryTask(Npc* n);

        virtual ~CheckIfHungryTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // CHECKIFHUNGRYTASK_H
