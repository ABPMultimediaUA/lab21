#include "Tree.h"

Tree::Tree(Npc* n, Map* m)
{

    /**** Initialize variables ****/

    tree = new Node* [100];

    numNodes = 0;

    brunning = false;

    npc = n;


    /**** Special nodes ****/

    Selector* selBehavior = new Selector;
    Selector* selAtHome = new Selector;
    Selector* selAtWork = new Selector;
    Selector* selCook = new Selector;
    Selector* selMoney = new Selector;
    Selector* selClean = new Selector;

    Sequence* seqAtHome = new Sequence;
    Sequence* seqAtWork = new Sequence;

    Sequence* seqHunger = new Sequence;
    Sequence* seqLunch = new Sequence;
    Sequence* seqCoffee = new Sequence;
    Sequence* seqBreak = new Sequence;
    Sequence* seqGoHome = new Sequence;
    Sequence* seqFreeTime = new Sequence;
    Sequence* seqSleepTime = new Sequence;

    Succeeder* sucSave = new Succeeder;


    /**** Task nodes ****/

    //CheckIfSleepingTask* checkSleep = new CheckIfSleepingTask (n);
    WakeUpTask* wakeUp = new WakeUpTask (n);
    CheckIfHungryTask* checkHungry = new CheckIfHungryTask (n);
    GoToTheKitchenTask* goKitchen = new GoToTheKitchenTask (n, m);
    CheckFoodTask* checkFood = new CheckFoodTask(n);
    HaveLunchTask* haveLunch = new HaveLunchTask (n);
    CookTask* cook = new CookTask (n);
    SaveLeftoversTask* leftovers = new SaveLeftoversTask (n);
    BrushTeethTask* brushTeeth = new BrushTeethTask ();
    GoToWorkTask* goWork = new GoToWorkTask (n, m);
    WorkTask* work = new WorkTask (n);
    CheckMoneyTask* checkMoney = new CheckMoneyTask (n);
    AskForMoneyTask* askMoney = new AskForMoneyTask (n);
    HaveCoffeeTask* haveCoffee = new HaveCoffeeTask (n);
    CheckBreakTimeTask* checkBreak = new CheckBreakTimeTask (n);
    TalkWithWorkmatesTask* talk = new TalkWithWorkmatesTask ();
    CheckFreeTimeTask* checkFree = new CheckFreeTimeTask(n);
    PlayVideoGamesTask* play = new PlayVideoGamesTask(n);
    CheckIfBedTimeTask* checkBedtime = new CheckIfBedTimeTask(n);
    CheckIfCleanTask* checkClean = new CheckIfCleanTask(n);
    HaveShowerTask* shower = new HaveShowerTask(n);
    PutOnPijamasTask* pijamas = new PutOnPijamasTask();
    SleepTask* sleep = new SleepTask(n);
    CheckAtHomeTask* checkHome = new CheckAtHomeTask (n);
    CheckAtWorkTask* checkWork = new CheckAtWorkTask (n);
    GoHomeTask* goHome = new GoHomeTask (n);
    CheckEndWorkTimeTask* checkEnd = new CheckEndWorkTimeTask (n);



    /**** All nodes in the tree ****/

    this->addNode(selBehavior);
    this->addNode(selAtHome);
    this->addNode(selAtWork);
    this->addNode(selCook);
    this->addNode(selClean);
    this->addNode(selMoney);

    this->addNode(seqAtHome);
    this->addNode(seqAtWork);
    this->addNode(seqHunger);
    this->addNode(seqLunch);
    this->addNode(seqCoffee);
    this->addNode(seqFreeTime);
    this->addNode(seqBreak);
    this->addNode(seqGoHome);
    this->addNode(seqSleepTime);

    this->addNode(sucSave);

    this->addNode(wakeUp);
    this->addNode(checkHungry);
    this->addNode(goKitchen);
    this->addNode(haveLunch);
    this->addNode(checkFood);
    this->addNode(brushTeeth);
    this->addNode(leftovers);
    this->addNode(cook);
    this->addNode(goWork);
    this->addNode(work);
    this->addNode(checkMoney);
    this->addNode(askMoney);
    this->addNode(haveCoffee);
    this->addNode(checkBreak);
    this->addNode(talk);
    this->addNode(checkFree);
    this->addNode(play);
    this->addNode(checkBedtime);
    this->addNode(checkClean);
    this->addNode(shower);
    this->addNode(pijamas);
    this->addNode(sleep);
    this->addNode(checkHome);
    this->addNode(checkWork);
    this->addNode(goHome);
    this->addNode(checkEnd);



    /**** Creating the tree ****/

    root = selBehavior;

    selBehavior->addChild(seqAtHome);
        seqAtHome->addChild(checkHome);
        seqAtHome->addChild(selAtHome);
            //selAtHome->addChild(seqSleep);
                //seqSleep->addChild(checkSleep);
            selAtHome->addChild(wakeUp);
            selAtHome->addChild(seqHunger);
                seqHunger->addChild(checkHungry);
                seqHunger->addChild(goKitchen);
                seqHunger->addChild(seqLunch);
                    seqLunch->addChild(selCook);
                        selCook->addChild(checkFood);
                        selCook->addChild(cook);
                    seqLunch->addChild(haveLunch);
                    seqLunch->addChild(sucSave);
                        sucSave->setChild(leftovers);
                    seqLunch->addChild(brushTeeth);
            selAtHome->addChild(seqFreeTime);
                seqFreeTime->addChild(checkFree);
                seqFreeTime->addChild(play);
            selAtHome->addChild(seqSleepTime);
                seqSleepTime->addChild(checkBedtime);
                seqSleepTime->addChild(selClean);
                    selClean->addChild(checkClean);
                    selClean->addChild(shower);
                seqSleepTime->addChild(pijamas);
                seqSleepTime->addChild(sleep);
            selAtHome->addChild(goWork);

    selBehavior->addChild(seqAtWork);
        seqAtWork->addChild(checkWork);
        seqAtWork->addChild(selAtWork);
            selAtWork->addChild(seqCoffee);
                seqCoffee->addChild(checkHungry);
                seqCoffee->addChild(selMoney);
                    selMoney->addChild(checkMoney);
                    selMoney->addChild(askMoney);
                seqCoffee->addChild(haveCoffee);
            selAtWork->addChild(seqBreak);
                seqBreak->addChild(checkBreak);
                seqBreak->addChild(talk);
            selAtWork->addChild(seqGoHome);
                seqGoHome->addChild(checkEnd);
                seqGoHome->addChild(goHome);
            selAtWork->addChild(work);

}

Tree::~Tree()
{
    //dtor
    Node* n;
    int i;
    for (i = 0; i < numNodes; i++)
    {
        n = tree[i];
        delete n;
    }

    delete[] tree;
}

Node** Tree::getTree()
{
    return tree;
}

int Tree::getNumNodes()
{
    return numNodes;
}

States Tree::run()
{
    npc->setTime();
    return root->run();
}

void Tree::addNode (Node* node)
{
    tree[numNodes] = node;
    numNodes++;
}

Node* Tree::getRoot()
{
    return root;
}
