#include "trigger.h"

trigger::trigger(int a, int b, int c, int d)
{
    region=new triggerRegion(a, b, c, d);
    triggered=false;
}

trigger::~trigger()
{
    delete region;
}

void trigger::isTriggered()
{
    triggered=true;
}

void trigger::update()
{

}
