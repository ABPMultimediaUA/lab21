#include "GoHomeTask.h"

GoHomeTask::GoHomeTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

GoHomeTask::~GoHomeTask()
{
    //dtor
}

States GoHomeTask::run()
{
    cout<<"At home."<<endl;
    npc->setLocation(home);
    return success;
}
