#ifndef WORKTASK_H
#define WORKTASK_H

#include "Node.h"

#include "Npc.h"

class WorkTask : public Node
{
    public:

        WorkTask(Npc* npc);

        virtual ~WorkTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
};

#endif // WORKTASK_H
