#include "CheckAtWorkTask.h"

CheckAtWorkTask::CheckAtWorkTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;
}

CheckAtWorkTask::~CheckAtWorkTask()
{
    //dtor
}

States CheckAtWorkTask::run()
{
    if(npc->getLocation() == work)
    {
        cout << "I'm at work." << endl;
        return success;
    }

    return failure;
}
