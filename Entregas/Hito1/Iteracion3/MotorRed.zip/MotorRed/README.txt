Ejecutar primero Server.exe
Luego varias instancias de game.exe

El personaje se controla con los cursores. El movimiento
y la rotación del personaje de cada uno de los clientes
es replicado al resto.