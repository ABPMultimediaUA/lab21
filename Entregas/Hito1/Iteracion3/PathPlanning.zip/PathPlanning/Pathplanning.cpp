#include<iostream>

using namespace std;


class Nodo{
    int x;
    int y;
    public:
        int getx(){return x;}
        int gety(){return y;}
        void set_values(int, int);
        void setX(int);
        void setY(int);
};

void Nodo::set_values (int posx, int posy) {
  x = posx;
  y = posy;
}
void Nodo::setX (int posx) {
  x = posx;
}
void Nodo::setY (int posy) {
  y = posy;
}
Nodo posInicio;
Nodo posNodo;
Nodo posDestino;
int mapa[][12]={
    {0,0,0,0,0,0,0,0,0,0,0,0},                //0: camino
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0,0,0}
    };

void imprimirMapa(){
    for(int j=0;j<12;j++){ //imprimimos el mapa del recorrido
        for(int k=0;k<12;k++){
            cout<<mapa[j][k]<<",";
        }cout<<endl;
    }
}

void camino(){

int origenX=13;//para que continue el bucle desde el principio
int origenY=13;
int destinoX=13;//para que continue el bucle desde el principio
int destinoY=13;
int danyo=0;

while (origenX>11 || origenX<0){
    cout<<"Introduce la posOrigen x: ";
    cin>>origenX;
    if(origenX>11 || origenX<0)
        cout<<"Debe ser menor de 12 y mayor o igual a 0"<<endl;
}
while (origenY>11 || origenY<0){
    cout<<"Introduce la posOrigen y: ";
    cin>>origenY;
    if(origenY>11 || origenY<0)
        cout<<"Debe ser menor de 12 y mayor o igual a 0"<<endl;
}

while (destinoX>11 || destinoX <0){
    cout<<"Introduce la posDestino x: ";
    cin>>destinoX;
    if(destinoX>11 || destinoX <0)
        cout<<"Debe ser menor de 12 y mayor o igual a 0"<<endl;
}
while (destinoY>11 || destinoY<0){
    cout<<"Introduce la posDestino y: ";
    cin>>destinoY;
    if(destinoY>11 || destinoY<0)
        cout<<"Debe ser menor de 12 y mayor o igual a 0"<<endl;
}
posInicio.set_values(origenX,origenY);
posNodo.set_values(origenX,origenY);
posDestino.set_values(destinoX,destinoY);
mapa[posInicio.getx()][posInicio.gety()]=3; // marcamos como 3 la salida

    while((posNodo.getx()<posDestino.getx() || posNodo.gety()<posDestino.gety() || posNodo.getx()>posDestino.getx() || posNodo.gety()>posDestino.gety()) && danyo==0){ //mientras sean menores de que las de destino y no haya danyo avanzamos sumamos
        if(posNodo.getx()<posDestino.getx()){
            posNodo.setX(posNodo.getx()+1);
        }

        if(posNodo.gety()<posDestino.gety()){
            posNodo.setY(posNodo.gety()+1);
        }
        if(posNodo.getx()>posDestino.getx()){
            posNodo.setX(posNodo.getx()-1);
        }

        if(posNodo.gety()>posDestino.gety()){
            posNodo.setY(posNodo.gety()-1);
        }
        cout<<"Avanzo a: ";
        cout<<"("<<posNodo.getx()<<","<<posNodo.gety()<<")"<<endl;
        for(int i=0;i<8;i++){ // marcamos como 1 los pasos del recorrido
            mapa[posNodo.getx()][posNodo.gety()]=1;
        }
        if(posNodo.getx()!=posDestino.getx() || posNodo.gety()!=posDestino.gety()){ //mientras no lleguemos al destino podemos recibir danyo
            cout<<"Recibo danyo? (si=1/no=0)"<<endl;
            cin>>danyo;
        }

    }

    if(posNodo.getx()==posDestino.getx() && posNodo.gety()==posDestino.gety())
        mapa[posNodo.getx()][posNodo.gety()]=4;
    cout<<"*-----------------------*"<<endl;
    cout<<"Mapa de recorrido (sin recibir danyo) al destino: "<<endl;

    imprimirMapa();//imprimimos el mapa del recorrido


    //RECIBIMOS DANYO//

    if(danyo==1){//en caso de recibir danyo cambiamos la ruta hacia atras huida
        cout<<"--He recibido danyo, huyo--"<<endl;
        mapa[posNodo.getx()][posNodo.gety()]=5; // marcamos el punto al que alcanza
        while(posNodo.getx()>posInicio.getx() || posNodo.gety()>posInicio.gety() || posNodo.getx()<posInicio.getx() || posNodo.gety()<posInicio.gety()){ //mientras sean menores de que las de destino y no haya danyo avanzamos sumamos
            if(posNodo.getx()>posInicio.getx()){
                posNodo.setX(posNodo.getx()-1);
            }

            if(posNodo.gety()>posInicio.gety()){
                posNodo.setY(posNodo.gety()-1);
            }
            if(posNodo.getx()<posInicio.getx()){
                posNodo.setX(posNodo.getx()+1);
            }

            if(posNodo.gety()<posInicio.gety()){
                posNodo.setY(posNodo.gety()+1);
            }
            //cout<<"("<<posNodo.getx()<<","<<posNodo.gety()<<")"<<endl;
            for(int i=0;i<12;i++){ // marcamos como 2 los pasos del recorrido de huida
                //if(posNodo.getx()!=posInicio.getx() && posNodo.gety()!=posInicio.gety()) // no pintamos de huida la posicion de inicio
                mapa[posNodo.getx()][posNodo.gety()]=2;
            }
            //imprimirMapa();


        }
        cout<<"*-----------------------*"<<endl;
        cout<<"Mapa de recorrido completo: "<<endl;

        imprimirMapa();//imprimimos el mapa del recorrido
    }



}



void limpiarMapa(){
    for(int j=0;j<12;j++){ //limpiamos el recorrido
        for(int k=0;k<12;k++){
            mapa[j][k]=0;
        }
    }
}

int main(){
cout<<"PRUEBA DE PATH PLANNING"<<endl;
cout<<"El inicio se indica con un 3"<<endl;
cout<<"El camino que realiza sin recibir danyo se indica con un 1"<<endl;
cout<<"El destino se indica con un 4(en caso de que lo alcance)"<<endl;
cout<<"El ultimo punto al que llega se indica con un 5"<<endl;
cout<<"En caso de recibir danyo dara vuelta atras y huira"<<endl;
cout<<"Es un mapa 12x12"<<endl;
cout<<"*----------------------------------*"<<endl;

int comenzar;
cout<<"Pulsa 0 para comenzar: ";
cin>>comenzar;
    while(comenzar == 0){
        camino();
        limpiarMapa();//reiniciamos el mapa
        cout<<"Pulsa 0 para repetir";
        cin>>comenzar;
    }


}
