 /\/\/\/\/\/\/\/\/\/\/\/\
( DireWolf Games - Lab21 )
 \/\/\/\/\/\/\/\/\/\/\/\/

This executable shows the output of each iteration in the route of a scene tree.

Just execute run.bat and see the console's output.

                   Root
              /      |     \
            1        2      3
          /   \     /      /
        4      5   9      10
      /  \    /          /  \
     6   7   8         11   12

------------
Rubén Moreno