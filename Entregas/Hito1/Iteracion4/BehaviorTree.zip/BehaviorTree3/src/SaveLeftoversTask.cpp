#include "SaveLeftoversTask.h"

SaveLeftoversTask::SaveLeftoversTask(Npc* n)
{
    //ctor
    brunning = false;
    npc = n;

}

SaveLeftoversTask::~SaveLeftoversTask()
{
    //dtor
}

States SaveLeftoversTask::run()
{
    cout << "COMIDA " << npc->getFood() << endl;
    if (npc->getFood() > 0)
    {
        cout << "Saving leftovers." << endl;
        return success;
    }

    return failure;
}
