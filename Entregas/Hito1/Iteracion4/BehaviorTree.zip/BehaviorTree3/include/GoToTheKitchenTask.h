#ifndef GOTOTHEKITCHENTASK_H
#define GOTOTHEKITCHENTASK_H

#include "Node.h"

#include "Npc.h"

#include "Map.h"


class GoToTheKitchenTask : public Node
{
    public:

        GoToTheKitchenTask(Npc* n, Map* m);

        virtual ~GoToTheKitchenTask();

        virtual States run();

    protected:

    private:

        Npc* npc;
        Map* mapa;
};

#endif // GOTOTHEKITCHENTASK_H
